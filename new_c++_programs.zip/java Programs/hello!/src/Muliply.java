import java.util.Scanner;
import java.util.scanner;
public class Muliply {

	public static void main(String[] args) {
		int a,b,c;
		
		System.out.print("Enter any Numbers:");
		Scanner purpose=new Scanner(System.in);
		
		a=purpose.nextInt();
		b=purpose.nextInt();
		
		c=a*b;
		
		System.out.println("the multiply is:"+c);
		

	}

}
