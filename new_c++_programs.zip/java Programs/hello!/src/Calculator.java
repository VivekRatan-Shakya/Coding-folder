import java.util.Scanner;

public class Calculator {

	public static void main(String[] args) {
		System.out.println("Enter any two Numbers:");
		Scanner love=new Scanner(System.in);
		float calculate;
		float x=love.nextFloat();
		float y=love.nextFloat();
		
		System.out.println("Enter Your Choice +,-,*/");
		char ch=love.next().charAt(0);
		switch(ch)
		{
			case '+':
				calculate=x+y;
				System.out.println("Sum is ="+calculate);
				break;
				
			case '-':
				calculate=x-y;
				System.out.println("Substration is ="+calculate);
				break;
				
			case '*':
				calculate=x*y;
				System.out.println("Multiply is ="+calculate);
				break;
				
			case '/':
				calculate=x/y;
				System.out.println("devide is ="+calculate);
				
			default:System.out.println("Sorry!! Invalid Choice:");
			
			
			
		}
		
		
		
		
		
		
		

	}

}
