// Method Overloading;
 /*package src;
class a
{
	void show()
	{
		int a=11, b=30,c;
		c=a+b;
		{
			System.out.println(c);
		}
	}
void show(int x,int y)
{
	int c;
	c=x*y;
	{
		System.out.println(c);
	}
}
void show(int x, double y)
{
	double c;
	c=x/y;
	{
		System.out.println(c);
	}
}
}

public class e {

	public static void main(String[] args) {
		
		a s=new a();
		 s.show();
		 s.show(600,700);
		 s.show(210,30.10);
	}
}
// Method Overloading;
*/


package src;
class a
{
	int show()
	{
		int a=11, b=30,c;
		c=a+b; 
		
	return c;
}
int show(int x,int y)
{
	int c;
	c=x*y;
	
	return c;
}
  double show(int x, double y)
{
	double c;
	c=x/y;      
	return c;
}
}
public class print {

	public static void main(String[] args) {
		
		a s=new a();
		 int d=s.show();
		int k=s.show(600,700);
		 double l=s.show(210,30.10);
		{
			 System.out.println(d);
			 System.out.println(k);
			 System.out.println(l);
		 }
	}

}
