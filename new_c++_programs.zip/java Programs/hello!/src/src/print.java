package src;
class a
{
	void show()
	{
		int a=11, b=30,c;
		c=a+b;
		{
			System.out.println(c);
		}
	}
void show(int x,int y)
{
	int c;
	c=x*y;
	{
		System.out.println(c);
	}
}
void show(int x, double y)
{
	double c;
	c=x/y;
	{
		System.out.println(c);
	}
}
}

public class e {

	public static void main(String[] args) {
		
		a s=new a();
		 s.show();
		 s.show(600,700);
		 s.show(210,30.10);
	}
}