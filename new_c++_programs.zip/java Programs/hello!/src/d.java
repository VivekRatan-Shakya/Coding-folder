!


public class d {

	
	int a=50;
	static double b=20.3;
	public static void main(String[] args) {
		
		boolean c=true;
		
		second s=new second();
		System.out.println(s.a+" "+b+" "+c);

}

}
