import java.util.Scanner;
class for_loop
{
	public static void main(String[] args)
	{
		System.out.println("Enter any Number:");
		 System.out.print("The Table is=:");
		Scanner heart=new Scanner(System.in);
		int num;
	   num=heart.nextInt();
	   for(int i=1;i<=10;i++)
	   {
		  
		   System.out.println(num*i);
	   }
	 
		
	}
}