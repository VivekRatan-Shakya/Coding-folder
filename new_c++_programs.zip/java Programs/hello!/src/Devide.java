import java.util.Scanner;
public class Devide {

	public static void main(String[] args)
	{
		

		int a,b,c;
		
		System.out.println("Enter any Numbers:");
		Scanner love=new Scanner(System.in);
		
		a=love.nextInt();
		b=love.nextInt();
		c=a/b;
		
		System.out.println("The devise is:"+c);
		
		
		
	}
}

