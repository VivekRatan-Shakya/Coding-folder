import java.util.Scanner;

public class Sum_big {

	public static void main(String[] args) {
		
		int a,b,c,d,e,f,g;
		
		System.out.print("Enter any Numbers:");
		Scanner love=new Scanner(System.in);
		
		a=love.nextInt();
        b=love.nextInt();
        c=love.nextInt();
        d=love.nextInt();
        e=love.nextInt();
        f=love.nextInt();
        
        g=a+b+c+d+e+f;
        
        System.out.println("Sum of big all Numbers:"+g);
        
        
		
		
	}

}
