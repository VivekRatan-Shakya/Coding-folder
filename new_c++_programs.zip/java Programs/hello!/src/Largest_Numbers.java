import java.util.Scanner;
public class Largest_Numbers {
	
	    public static void main(String args[])
	    {
	       System.out.println("Enter any Three Numbers:");
	       Scanner look=new Scanner(System.in);
	       int heart=look.nextInt();
	       int life=look.nextInt();
	       int face=look.nextInt();
	       
	       {
	           if(heart>life && heart>face)
	           System.out.println("is a Largest Number:"+heart);
	           break;
	           
	           else if(life>heart && life>face)
	           System.out.println("is a Largest Number:"+life);
	           break;
	           
	           else(face>heart && face>life)
	           System.out.println("is a Largest Number:"+face);
	           break;
	           
	           
	           
	       }
	       
	       
	   }
	    
	}

