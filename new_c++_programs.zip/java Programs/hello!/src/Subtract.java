import java.util.Scanner;

public class Subtract {

	public static void main(String[] args) {
		
		int a,b,c;
		
		System.out.println("Enter any Two Numbers:");	
		Scanner love=new Scanner(System.in);
		
		a=love.nextInt();
		b=love.nextInt();
		c=a-b;
		
		System.out.println("The Subtrsction is:"+c);
		
	}
	

}
