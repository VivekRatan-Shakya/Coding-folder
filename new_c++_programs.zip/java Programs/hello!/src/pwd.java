import java.util.Scanner;
public class pwd {
     public static void main(String[] args) {
	 int pwd;
		System.out.println("Enter password:=");
		Scanner love=new Scanner(System.in);
		pwd=love.nextInt();
		if(pwd==4980)
		{
		System.out.println("My Name Suman:");
		System.out.println("My Adge 30:");
		System.out.println("My Class Second:");
		System.out.println("My favorite Song:");2050225
		System.out.println("My Address Mathura Road Chhata,UP:");
		}
		else
		{
			System.out.println("Sorry! Wrong Password:");
		}

	}
}


