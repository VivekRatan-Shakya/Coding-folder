import java.util.Scanner;
public class nested_ifelse {
	
	public static void main(Strin[] args)
	{
		
		int num1,num2,num3;
		
		if(num1>num2)
		{
			System.out.println("Maximam Number:"+num1);
			
		}
		else
		{
			System.out.println("Maximan Number:"+num3);
			
		}
		else
		{
			System.out.println("Maximam NUmber:"+num2);
		}
			
			
	}
}
