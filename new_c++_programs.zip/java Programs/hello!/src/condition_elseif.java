import java.util.Scanner;
public class condition_elseif{
public static void main(String[] args)
	{int mark;
		System.out.println("Enter the Marks");
		Scanner obj=new Scanner(System.in);
		mark=obj.nextInt();
		if(mark>=60&&mark<=100)
		{System.out.println("Frist Division:");}
		else if(mark>=45&&mark<60)
		{System.out.println("Second Division:");}
		else if(mark>=33&&mark<45)
		{System.out.println("Third Division:");}
		else
			
		{System.out.print("Fail");}
			
}
}

	
	
	
	
	
	
