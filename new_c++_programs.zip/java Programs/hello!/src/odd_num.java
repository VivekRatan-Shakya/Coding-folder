import java.util.Scanner;
		public class odd_num{
			public static void main(Strin args[]);
			{
				
				System.out.println("Enter any Number:");
				Scanner love=new Scanner(System.in);
				int num;
				num=love.nextInt();
				
				while(num>0)
					if(num%2==0)
					{
						System.out.println("Even Number:"+num);
						
					}
					else
					{
						System.out.println("Odd Number:"+num);
					}
			}

		}

	}

}
