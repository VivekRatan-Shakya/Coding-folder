
class B
{
	int x,y;
	B(int a,int b) //parameterized
	{
		x=a; y=b;
	}
	void show()
	{
		System.out.println(x+"\n"+y);
	}
}

 public class A_parameters {

	public static void main(String[] args) {
		
		A r=new A(10,20);
		r.show();
		

	}

}
