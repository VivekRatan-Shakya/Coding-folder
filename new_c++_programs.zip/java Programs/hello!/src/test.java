
public class test
{

    public static void main(String[] args)
    {

        String s1 = "abc";
        String s2 = "ABC";

        System.out.println("s1.compilor(s2)");
    }
}
