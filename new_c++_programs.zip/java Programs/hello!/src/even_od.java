import java.util.Scanner;
public class even_od {
	
	public static void main(String args[])
	
	{
		System.out.println("Enter any Number:");
		Scanner love=new Scanner(System.in);
		 int num;
		 num=love.nextInt();
		 
		 if(num%2==0)
		 {
			 System.out.println("is a Even Number:"+num);
		 }
		 else
		 {
			 System.out.println("is a odd Number:"+num);
		 }
		 
	}

}
