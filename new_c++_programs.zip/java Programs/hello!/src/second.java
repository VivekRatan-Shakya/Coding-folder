
public class second {

	int a=10;
	static double b=20.2;
	public static void main(String[] args) {
		
		boolean c=true;
		
		second s=new second();
		System.out.println(s.a);
		System.out.println(b);
		System.out.println(c);
	}

}
