import java.util.Scanner;
public class operation_calculators {
	
	{
	    Public Static Void Main(String[] args);
	    System.out.println("Enter the any two Numbers:");
	    Scanner life=new Scanner(System.in);
	    double  operations;
	    double  love=life.nextDouble();
	    double  heart=life.nextDouble();
	    System.out.println("Enter any operation +,-,*,/");
	    char    ch=life.nextChar().charAt(0);
	    switch(ch)
	    {
	    case '+':
	        operation=love+heart;
	        System.out.println("sum is = "+operation);
	        break;
	        
	        case '-':
	            operation=love-heart;
	            System.out.println("Substraction is = "+operation);
	            break;
	            
	            case '*':
	                operation=love*heart;
	                System.out.println("Multiply is = "+operation);
	                break;
	                
	                case '/';
	                operation=love/heart;
	                System.out.println("Devide is = "+operation);
	                break;
	        
	        default:System.out.print("Sorry!! Invalid Your Choice:");
	        
	        
	    }
	    
	}

}
