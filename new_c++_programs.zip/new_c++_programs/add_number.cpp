#include<iostream>
using namespace std;

class A
{
    public:
    void add()
    {
        int a,b,c;
        cout<<"Enter any two Numbers:"<<endl;
        cin>>a>>b;
        c=a+b;
        cout<<"Result is = "<<c;
    }

};
int main()
{
    A obj;
    obj.add();
    return 0;

}