#include<iostream>
using namespace std;
 int main()
 {
    int n;
    cout<<"d"<<endl;
    cin>>n;
    cout<<n;
 }