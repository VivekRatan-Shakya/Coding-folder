// Abstract class for Virtual keywords   we don,t creat for abstract object;
#include<iostream>
using namespace std;
class animal
{ public:
    virtual void sound()=0;
    void show()
    {
        cout<<"Eat the Meals & foods:"<<endl;
    }
};
class camel:public animal
{
     public:
     void sound()
     {
         cout<<"Woof Woof...."<<endl<<"Uooaa UUoooaaa.."<<endl;
     }
};
int main()
{
 camel obj;
 obj.sound();
 obj.show();
 return 0;
}













// #include<iostream>
// using namespace std;
// class A
// {
//     public:
//     virtual void show()=0;
//     void shw()
//     {
//         cout<<"Your Result is Successfull:"<<endl;
//     }
// };
// class B: public A
// {   public:
//     void show()
//     {
//         cout<<"Did You Like me:"<<endl;
//     }
// };
// int main()
// {

//  B obj;
//  obj.show();
//  obj.shw();



//     return 0;
// }
