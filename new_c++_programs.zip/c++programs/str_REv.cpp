#include<iostream>
#include<string.h>
using namespace std;
int main()
{
              // concate String pro;
        // char str1[]="Ankit";                 
        // char str2[]="Kumar:";

        //  strcat(str1,str2);
        //   cout<<str1;


// Copy String;

        //  char str1[]="Ankit";                 
        //  char str2[20];

        //  strcpy(str2,str1);
        //   cout<<str2;



//Reverse string:

        //    char str1[]="Ankit";                 
         
        //    cout<<strrev(str1);

    


//string length;

        // char str1[]="Ankit";                 
         
        //  cout<<strlen(str1);






//string lower/Upper;

        //  char str1[]="ANKIT";                 
        //  char str2[]="ankit";

        //   cout<<strlwr(str1);
        //   cout<<endl;
        //   cout<<strupr(str2);






}
