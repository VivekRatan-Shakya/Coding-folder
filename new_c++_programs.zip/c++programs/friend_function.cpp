#include<iostream>
using namespace std;
class A
{
   public:
   int a=10 ,b=20;
};
class B :public A
{
    public:
    void add()
    {
        int c;
        c=a+b;
        cout<<"The sum is "<<c<<endl;
    }
};
int main()
{
 B obj;
 obj. add();

    return 0;
}
    