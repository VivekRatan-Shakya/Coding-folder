#include<iostream>
#include<string.h>
using namespace std;
int main()
{
    {
      char str1[]="Ankit";                 //print string
      char str2[]="Ankit";                 //string length
      char str3[]="Kumar;"                      //string copy  
      //char str4[10];                         //string reverse
     // char str5[6];                         //string concate 
      //char str[7];                         //string lower
      //char str8[8];                        //string upper

      //cout<<str<<endl;;
      //cout<<strlen(str2)<<endl;
      strcpy(str1,str3);
      cout<<str1;





  }
}