#include<iostream>
using namespace std;
int main()
{
   int a[3][3];
    int i,j,num;
    cout<<"Enter Array Eliments:"<<endl;
    for(i=0;i<num;i++)
    {
        for(j=0;j<num;j++)
        cin>>num;
    }
    cout<<"Result shoing in Array Eliments:"<<endl;
      for(i=0;i<num;i++)
      {
          for(j=0;j<num;j++)

          cout<<a[i][j];
      }
    
    return 0;
}
