#include<iostream>
using namespace std;
int main()
{
 int a[5][5],i,j;
 cout<<"Enter Array Eliments:"<<endl;
 for(i=0;i<=1;i++)
 {
     for(j=0;j<=1;i++)
     cin>>a[i][j];
 }   
cout<<"Array Eliments:"<<endl;
 for(i=0;i<=1;i++)
 {
     for(j=0;j<=1;j++)

     cout<<a[i][j]<<endl;
}

 

return 0;

}
