#include<iostream>
using namespace std;
int main()
{

int a,b;

cout<<"Enter any two numbers:"<<endl;
cin>>a>>b;

if(a>b)
{
    cout<<a;

}
else{

    cout<<"This largest number:"<<b;
}


}