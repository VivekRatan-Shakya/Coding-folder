#include<iostream>
using namespace std;
int main()
{


    int a=10;
    int *p;

    // cout<<"Enter any Numbers:"<<endl;
    // cin>>a;

     p=&a;

    cout<<&a<<endl;
    cout<<p<<endl;


    cout<<a<<endl;
    cout<<*p;

    //cout<<
}