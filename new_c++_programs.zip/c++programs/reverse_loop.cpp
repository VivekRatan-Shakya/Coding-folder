#include<iostream>
using namespace std;
int main()
{

int a;

cout<<"Enter any numbers:"<<endl;
cin>>a;

while(a>=5)
{
    cout<<"Reverse numbers:"<<a<<endl;
    --a;
}

return 0;
 }



