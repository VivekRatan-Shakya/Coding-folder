#include<iostream.h>

using namespace std;
int main()
{
    int a,b;
    cout<<"Enter two no"<<endl;
    cin>>a>>b;

    cout<<a+b<<endl;
}