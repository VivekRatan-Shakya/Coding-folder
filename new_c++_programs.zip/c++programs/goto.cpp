#include<iostream>
using namespace std;
int main()
{

    int age;
    cout<<"Enter your age:"<<endl;
    cin>>age;

   if(age>=18)
   goto Vote;
   else;
   goto notVote;

   Vote:
   cout<<"Youe are Eligible for Vote:"<<endl;
   return 0;
   notVote:
   cout<<"You are not Eligible for Vote:";

 return 0;

}