#include<iostream>
using namespace std;
int main()
{
    int num,i;
    cout<<"Enter any numbers:"<<endl;
    cin>>num;

    for(i=1;i<=num;i++)
    {
        if(i==9)
        continue;
        cout<<i<<endl;

    } 
    return 0;
}