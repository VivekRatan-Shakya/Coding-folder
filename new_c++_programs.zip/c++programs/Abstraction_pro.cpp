#include<iostream>
using namespace std;
class A
{
    private:
    int atmpin,balance;
   public:
    int accNumber;
    string bankname,IFSCcode;

    void input()
    {
       atmpin=2030;
       balance=963254;
       accNumber=523654565;
       bankname="HDFC";
       IFSCcode="HDFC000230";       
        
    }  
        void output()
        {
           cout<<"Your Bank Details...."<<endl;
           cout<<"Your BankName is:"<<bankname<<endl;
           cout<<"Bank IFSCcode: "<<IFSCcode<<endl;
           cout<<"Your Account Number:"<<accNumber<<endl;
           cout<<"Your AMT pin:"<<atmpin<<endl;
           cout<<"Your Total Balance:"<<balance<<endl;
        }
    
    
};
int main()
{
     A obj;
     obj.input();
     obj.output();





        //    cout<<"Your Bank Details...."<<endl<<"Raj Access YOur Details..."<<endl;
        //    cout<<"Your BankName is:"<<bankname<<endl;
        //    cout<<"Bank IFSCcode: "<<IFSCcode<<endl;
        //    cout<<"Your Account Number:"<<accNumber<<endl;
          // cout<<"Your AMT pin:"<<atmpin<<endl;
          // cout<<"Your Total Balance:"<<balance<<endl;


     return 0;

}