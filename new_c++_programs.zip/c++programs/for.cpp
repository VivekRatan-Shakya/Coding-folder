#include<iostream>
using namespace std;
int main()
{

int a,i=0;

cout<<"Enter any numbers:"<<endl;
cin>>a;

for(i=0;i<=a;--i)
{
    cout<<"The natural number is= "<<i<<endl;
}
return 0;
}