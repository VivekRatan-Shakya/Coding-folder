// calculater program for c++:
#include<iostream>
using namespace std;
int main()
{
int a,b,ch;
int add,mul,dev,sub;
cout<<"Enter any two numbers:"<<endl;
cin>>a>>b;
cout<<"Enter any operations +,-,*,/:"<<endl;
cin>>ch;
{
  if(ch==1)
 {
   add=a+b;
   cout<<"Addition is a ="<<add<<endl;
 }
 else if(ch==2)
  {
    sub=a-b;
    cout<<"The substraction is = "<<sub<<endl;
 } 

 else if(ch==3)
 {
     mul=a*b;
     cout<<"The multiply is = "<<mul<<endl;
 } 
 else if(ch==4)
 {
     dev=a/b;
     cout<<"The devide is = "<<dev<<endl;
 }
 else
 {
     cout<<" Sorry...!! invalid choice:";
 }

 return 0;
}




// switch(ch)
//  {
//      case '+':
//                 cout<<a+b<<endl;
//                 break;

//         case '-':
//                 cout<<a-b<<endl;
//                 break;

//         case '*':
//                 cout<<a*b<<endl;
//                 break;

//         case '/':
//                 cout<<a/b<<endl;
//                 break;

//         default:cout<<"Invalid character"<<endl;

    
//  }

}
