#include<iostream>
namespace A
{
     void print()
    {
         std::cout<<"hello..........";
         
    }
};
namespace B
{
    void print()
    {
         std::cout<<"Hi !.....";
    }
};
int main()
{
     A::print();
     B::print();

    return 0;
}