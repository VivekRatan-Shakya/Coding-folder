#include<iostream>
using namespace std;
class A
{
    public:
    void person()
    {
        cout<<"Love You My jaan:"<<endl;
    }

  void show()
    {
        cout<<"HI ! Hello...:"<<endl;
    }
    
};
class B:public A 
{
    public:
    void person()
    {
        cout<<"Do You Love Me:"<<endl;

    }

};
int main()
{
 B obj;
 obj.person();
 obj.A::show();
 obj.A::person();


 return 0;
}

