#include<iostream>
using namespace std;
struct student 
{

     char name[20];
     int roll;
     float marks;
     double per;
};
     
int main()
{
    struct student s;
    
      cout<<"Enter Stuent Name:"<<endl;
      cin>>s.name;
      cout<<"Enter Stuent Roll:"<<endl;
      cin>>s.roll;
      cout<<"Enter Student marks:"<<endl;
      cin>>s.marks;
      cout<<"Enter Student Percentage:"<<endl;
      cin>>s.per;


    //   cout<<"Studen name is = "<<s.name<<endl;
    //   cout<<"Student roll is = "<<s.roll<<endl;
    //   cout<<"Student marks is = "<<s.marks<<endl;
    //   cout<<"Student Percentage is = "<<s.per<<endl;

    cout<<s.name<<endl<<s.roll<<endl<<s.marks<<endl<<s.per<<endl;
     


}