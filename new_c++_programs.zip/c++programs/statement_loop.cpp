#include<iostream>
using namespace std;
int main()
{

int i=1,a;

cout<<"Enter any numbers:"<<endl;
cin>>a;

while(i<=a)
{
    cout<<"Natural nuymbers:" <<i<<endl;
     i++;
}

return 0;
}