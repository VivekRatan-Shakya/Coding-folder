// copy constructor;
#include<iostream>
using namespace std;
class A
{    float l;
     public:
   A(int a,float b)
 {
       float d;
       l=d=a+b; 
      cout<<"THe result is = "<<d<<endl;
  }
A(A &ref)
   {
      l=ref.l;
      cout<<"The result is = "<<l<<endl;
   }
};
int main()
{

    A obj(84,3434.090);
    A obj2=obj;
   

    return 0;
}



