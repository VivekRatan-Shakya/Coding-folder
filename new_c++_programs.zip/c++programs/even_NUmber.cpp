#include<iostream>
using namespace std;
int main()
{

    int num,i;

    cout<<"Enter any numbers:"<<endl;
    cin>>num;

      if(num%2==0)
      {
          cout<<"is a Even number:"<<endl;
      }
      else
      {
          cout<<"is a odd number:";
      }
      return 0;

}