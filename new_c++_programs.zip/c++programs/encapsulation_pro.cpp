#include<iostream>
using namespace std;
class Encapsulation
{
    private:
   string address,name;
   int mobile,id;

   public:
   void input()
   {
       address="Dehli Road Mukharchi Nagar";
       name="Suman_Kumar";
       id = 2036263;
       mobile = 2030506010;
   }
   void output()
       {
           cout<<"Your Personal Detail is:"<<endl;
           cout<<"Your Name is:"<<name<<endl;
           cout<<"Your Address is:"<<address<<endl;
           cout<<"Your Idcard Number is:"<<id<<endl;
           cout<<"Your mobile Number is:"<<mobile;

       }
};
class police :public Encapsulation
{

};

int main()
{

// Encapsulation obj;
// obj.input();
// obj.output();

cout<<" Access Police all Details.."<<endl;
police obj;
obj.input();
obj.output();


return 0;

}
