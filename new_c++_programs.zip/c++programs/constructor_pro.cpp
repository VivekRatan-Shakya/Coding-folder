// default constructors;

#include<iostream>
using namespace std;
class A
{
    int a,b,k;
    public:
   A()
   {
      a=10,b=20,k;
       k=a+b;
       cout<<"The Result is = :"<<k;
    }

};

int main()
{

    A obj=A();
    
  
   return 0;
}