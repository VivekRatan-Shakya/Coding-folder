#include<iostream>
using namespace std;
class animal
{
  public:
  void behaviour()
  {
    cout<<"all animals has four foot:"<<endl;
    cout<<"all animals  eat the meals:"<<endl;
    cout<<"all animals has two eyes:";
  }
};
class B : public animal
{
  public:
  void Dog()
  {
      cout<<"The Dog  woooh woooh"<<endl;
      cout<<"The Dog is Weapet noo nooo"<<endl; 
  }
};
class C: public animal
{
  public:
  void Cow()
 {
   cout<<"The Cow is eat the green grass:"<<endl;
 }
};
class D : public animal
{  public:
   void Monkey()
 {
   cout<<"The Monkey is eat the banana:"<<endl;
 }
};
int main()
{
   animal a; a.behaviour();
   B b;  b.Dog();
   C c;  c.Cow();
   D d;  d.Monkey();



return 0;

}


