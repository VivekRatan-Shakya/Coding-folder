// #include<iostream>
// using namespace std;
// int main()
// {int age;

// cout<<"Enter Your Age:"<<endl;
// cin>>age;

// if(age>=18)
// {
//     cout<<"You are Eligible for vote:"<<endl;
// }
// else
// {
// cout<<"You are not Eligible for vote:";
// }

//return 0;
// }






#include<iostream>
using namespace std;
int main()
{int age;

cout<<"Enter Your Age:"<<endl;
cin>>age;

if(age>=18)
goto Vote;
else
goto notVote;

Vote:
cout<<"You are Eligible for Vote:"<<endl;
return 0;
notVote:
cout<<"You are not Eligible for Vote:";

return 0;
}