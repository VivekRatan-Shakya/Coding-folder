#include<iostream>
using namespace std;
union student 
{

     char name[20];
     int roll;
     float marks;
     double per;
};
     
int main()
{
    union student s;
    
      cout<<"Enter Stuent Name:"<<endl;
      cin>>s.name;
      cout<<"Studen name is = "<<s.name<<endl;

      cout<<"Enter Stuent Roll:"<<endl;
      cin>>s.roll;
      cout<<"Student roll is = "<<s.roll<<endl;

      cout<<"Enter Student marks:"<<endl;
      cin>>s.marks;
      cout<<"Student marks is = "<<s.marks<<endl;

      cout<<"Enter Student Percentage:"<<endl;
      cin>>s.per;
      
      //  cout<<s.name<<endl<<s.roll<<endl<<s.marks<<endl<<s.per<<endl;
     
return 0;

}