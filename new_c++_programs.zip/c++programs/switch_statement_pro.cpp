#include<iostream>
using namespace std;
int main()
{
char ch;
cout<<"Enter any choice:"<<endl;
cin>>ch;

switch(ch)
{
 case '1':
 cout<<"Sunday:";
 break;

 case  '2':
 cout<<"monday:";
 break;

 case '3':
 cout<<"tuesday:";
 break;

 case '4':
 cout<<"wednesday:";
 break;
  
 case '5':
 cout<<"thursday:";
 break;

 case '6':
 cout<<"friday:";
 break;

 case '7':
 cout<<"satuarday";
 break; 

 default:cout<<"Invalid Chioce:";

return 0;
}

}