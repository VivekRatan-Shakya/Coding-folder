#include<iostream>
using namespace std;
int main()
{
 int i, array[8]={10,20,30,40,50,60,70,80};
 for(i=0;i<8;i++)
   {
      cout<<array[i]<<endl;
   }
 }


 