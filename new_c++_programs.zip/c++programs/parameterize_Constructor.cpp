#include<iostream>
using namespace std;
class P
{ 
    public:
    P(int x,int y)
    
   {
       int z;
       z=x*y;
       cout<<"The Multiplication is = :"<<z<<endl;
   }
  
};

int main()
{
    P obj=P(100,900);
    return 0;
}

