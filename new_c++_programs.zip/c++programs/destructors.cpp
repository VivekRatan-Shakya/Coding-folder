#include<iostream>
using namespace std;
class A
{
    public:
    int count=0;
  A()
  {
      cout<<"created"<<++count<<"object"<<endl;
  }
~A()
 {

     cout<<"deleted"<<count--<<"object"<<endl;
 }
};
int main()
{

    A obj1,obj2,obj3,obj4;
}