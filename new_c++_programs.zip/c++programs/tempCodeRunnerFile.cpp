#include<iostream>
using namespace std;
class A 
{
    public:
    void prt()
    {
      
      int a,b,c;
      cout<<"Enter any Three Numbers:"<<endl;
      cin>>a>>b>>c;

      if(a>=b&&a>=c);
      {
        cout<<"  A "<<a;
      }
      else if
      {
        cout<<" B "<<c;
      }
      else
      {
        cout<<" C"<<c;
      }
    }
};
int main()
{
    A obj;
    obj.art();
    return 0;
}