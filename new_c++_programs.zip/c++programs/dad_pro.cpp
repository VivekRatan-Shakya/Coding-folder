#include<iostream.h>
using namespace std;

int main()
{

    cout<<"love mom dad";
    return 0;

}
