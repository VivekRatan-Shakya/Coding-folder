// #include<iostream>
// using namespace std;
// template <class B>
// void love(B y, B k)
// {
//     cout<<y<<endl<<k<<endl;
// };
// int main()
// {
//     love(22,30);

//     return 0;
// }

//   Template program in c++;

#include<iostream>
using namespace std;
template <class A>
void show(A x,A y)
{
  cout<<x<<endl<<y<<endl;
};
int main()
{
    show(10,20);
    show(102520,20602);
    show(10.20,2.00);
    show("love","babber");
    show(true,false);
    return 0;

}