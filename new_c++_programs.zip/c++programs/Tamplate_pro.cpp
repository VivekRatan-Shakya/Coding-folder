#include<iostream>
using namespace std;
tamplate class<A>
{
    
}