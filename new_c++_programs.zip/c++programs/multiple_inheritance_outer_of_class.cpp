// MULTIPLE INHERITANCE OUTER OF CLASS
#include<iostream>
using namespace std;
int a,b,c;
class A
{    public:
     void outpute();
     void inpute();
};
void A :: outpute()
{
   cout<<"Enter any two Numbers:"<<endl;
}
void A :: inpute()
{
  cin>>a>>b; 
}
/////////////////////////////////////////////////////////////
class B
{ public:
  void add();
};
void B :: add()
{
c=a+b; 
cout<<"The Addition perform is = "<<c<<endl;
}
//////////////////////////////////////////////////////////////
class C
{ public:
  void sub();
};
void C :: sub()
{
    c=a-b; 
    cout<<"The Substraction is = "<<c<<endl;
}
////////////////////////////////////////////////////////////////
class D:public A,public B,public C
{ public:
  void multi();
};
void D :: multi()
{
   c=a*b; 
   cout<<"The Multiplication is = "<<c<<endl;
   c=a/b; 
   cout<<"The devition is = "<<c<<endl;
}
int main()
{
    D obj;
    obj.outpute();
    obj.inpute();
    obj.add();
    obj.sub();
    obj.multi();


    return 0;
}