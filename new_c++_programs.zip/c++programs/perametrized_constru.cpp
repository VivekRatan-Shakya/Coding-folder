// perameterized copy constructors in c++ with help of class
#include<iostream>
using namespace std;
class A
   {  int o;
    public:
    A(int a,int b)
    {int c;
     o=c=a+b;
     cout<<"The result is Right = "<<c<<endl;
    }
A(A &ref)
  {
     o=ref.o;
    cout<<"The result is Right = "<<o;
  }
};
int main()
{
   A obj(50,60);
   A obj2=obj;
   return 0;
}
