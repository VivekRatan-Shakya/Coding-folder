#include<stdio.h>
// #include<conio.h>
// using namespace std;
// int main()
// {

// cout<<"Welcome";

// return 0;
// }



//#include <iostream.h>

using namespace std;

int main()
{
    cout<<"Hello World";

    return 0;
}
