#include<iostream>
using namespace std;
int main()
{
char ch;
cout<<"Enter any choice:"<<endl;
cin>>ch;

switch(ch)
{
 case 's':
 cout<<"Sunday:";
 break;

 case  'm':
 cout<<"monday:";
 break;

 case 't':
 cout<<"tuesday:";
 break;

 case 'w':
 cout<<"wednesday:";
 break;
  
 case 'th':
 cout<<"thursday:";
 break;

 case 'f':
 cout<<"friday:";
 break;

 case 'sa':
 cout<<"satuarday";
 break; 

 default:cout<<"Invalid Chioce:";

return 0;
}

}