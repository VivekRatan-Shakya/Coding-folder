#include<iostream>
using namespace std;
int main()
{

  int array[1][1],x,y;
  cout<<"Enter any Numners:"<<endl;

  for(x=0;x<=1;x++)
 {
    for(y=0;y<=1;y++)
   cin>>array[x][y];
 }


 cout<<"Show Array Eliments:"<<endl;
 for(x=0;x<=1;x++)
 {
     for(y=0;y<=1;y++)

     cout<<array[x][y]<<endl;
 }

return 0;
}
