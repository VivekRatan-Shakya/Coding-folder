#include<iostream>
using namespace std;
int main()
{

int x,y,max;

cout<<"Eneter any two numbers:"<<endl;
cin>>x>>y;

max=(x>y)?x:y;

  cout<<"The maximan number is "<<max;
  
return 0;



}