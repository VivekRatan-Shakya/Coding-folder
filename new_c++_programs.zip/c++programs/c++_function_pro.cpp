// #include<iostream>
// using namespace std;
// class print
// {
//    public:
//     void show()
//     {
        
//         int i=10,v=50,h;
//          h=i+v;
//         cout<<"The sun of = "<<v;
//  }
// };
//      int main()
// {
//      print obj;
//     obj.show();
 

// }










#include<iostream>
using namespace std;
class a
{
    public:
    void show()
    {
    int a=10,b=20, x;
    x=a-b;
    cout<<"show result:"<<x<<endl;
}

void show2()
{
    int a=10,h=60,l;
    l=h*a;
    cout<<"show2 result:"<<l<<endl;
}
void show3()
{
    int i,c,g;
    cout<<"Enter any two numbers:"<<endl;
    cin>>i>>g;
    c=g/i;
    cout<<"show3 result:"<<c;
}
};

int main()
{
    a obj;
    obj.show();
    obj.show2();
    obj.show3();
}









