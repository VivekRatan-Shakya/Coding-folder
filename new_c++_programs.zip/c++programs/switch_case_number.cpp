#include<iostream>
using namespace std;
int main()
{ 
    int a,b;
    char ch;
 cout<<"Enter any two numbers:"<<endl;
 cin>>a>>b;

 cout<<"Enter any operations +,-,*,/:"<<endl;
  cin>>ch;

switch(ch)
{
  case '+':
  cout<<a+b<<endl;
  break;

  case '-':
  cout<<a-b<<endl;
  break;

  case '*':
  cout<<a*b<<endl;
  break;

  case '/':
  cout<<a*b<<endl;
  break;

 default:cout<<"Sorry!! invalid choice:";

return 0;

}

}


