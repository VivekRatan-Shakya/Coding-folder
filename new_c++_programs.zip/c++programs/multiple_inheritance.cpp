//MULTIPLE INHERITANCE 
#include<iostream>
using namespace std;
int a,b,c;
class A
{
    public:
      void inpute()
      {
          cout<<"Enter any two Numbers:"<<endl;
          cin>>a>>b;
      }
};
class B
{
    public:
   void add()
   {
    c=a+b;
    cout<<"The Addition  is = "<<c<<endl;
   }

};
class C
{
    public:
    void outpute()
{
    c=a-b;
    cout<<"The Substraction is = "<<c<<endl;
}
};
class D:public A,public B,public C
{
    public:
    void good()
{
    c=a%b;
    cout<<"The Moduls is = "<<c<<endl;
    c=a*b; 
    cout<<"The Multiplication is = "<<c<<endl;
}
};
int main()
{
    D obj;
    obj.inpute();
    obj.add();
    obj.outpute();
    obj.good();

    return 0;
}
