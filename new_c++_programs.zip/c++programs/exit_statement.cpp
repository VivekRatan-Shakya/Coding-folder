#include<iostream>
using namespace std;
int main()
{

    cout<<"Enter any four Nubers:"<<endl;
    cout<<"Love you my sona and babu:"<<endl;
    cout<<"Hello hi janu:"<<endl;
    cout<<"How are you:"<<endl;
    exit(0);
    cout<<"What are you saying bro:"<<endl;
    cout<<"Are you ok:";
}