#include<iostream>
using namespace std;
int main()
{

int a;
cout<<"Enter your Atm pin:"<<endl;
cin>>a;
if(a==5076)
{
    cout<<"Your Money is Withdrawal Successful A/C XXXXXXXX2030"<<endl;
    cout<<"Debit Money is 200010  A/c XXXXXXXXX2030";
}
else
{
    cout<<" Sorry !!Incorrect Pin:";
}

 return 0;


}