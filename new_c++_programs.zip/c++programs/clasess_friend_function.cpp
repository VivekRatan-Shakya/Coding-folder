#include<iostream>
using namespace std;
class Vivek
{
    string tv;
     public:
     void show()
     {
        tv="I am Watching South Movie:";
     }   
      friend void aman(Vivek r);
};
void aman(Vivek r)
{
    cout<<r.tv;
}
int main()
{
 Vivek obj;
 obj.show();
 aman(obj);

    return 0;
}