#include<iostream>
using namespace std;
int main()
{
 int a,b;

 cout<<"Enter any two number:"<<endl;
 cin>>a>>b;

 cout<<"The sum is = "<<a+b;

 return 0;

}