#include<iostream>
using namespace std;
class A
{

    int a=10,b=30;
    public:
    friend class B;

};
class B
{   
    int c;
    public:
    void show(A r)
    {
        c=r.a+r.b;
        cout<<"The Result is = "<<c<<endl;
    }
};
int main()
{   A a;
    B obj;
    obj.show(a);
    return 0;
}