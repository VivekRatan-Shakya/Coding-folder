//Compiletime poloymorphism(Method overloading)=Same name funtion and different type of parameters:
#include<iostream>
using namespace std;
class A
{   
 public:
 void show(int a,int b)
 {
    int c;
    c=a+b;
    cout<<"Sum is = "<<c<<endl;
 }
};
class B
{
    public:
  void show(int a,float b)
  {
   float c;
   c=b-a;
   cout<<"substraction is = "<<c<<endl;

  }
};
class C
{
    public:
    void show(int a,float b)
    {
        double c;
        c=b*a;
        cout<<"Multiplication is = "<<c<<endl;
    }
};
int main()
{
A obj;   obj.show(34,67);
B obj2;  obj2.show(23,98.0);
C obj3;  obj3.show(89,99.90);





return 0;
}