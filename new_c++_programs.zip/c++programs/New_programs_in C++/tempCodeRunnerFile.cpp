
       cin>>pen>>pencil>>eraser;