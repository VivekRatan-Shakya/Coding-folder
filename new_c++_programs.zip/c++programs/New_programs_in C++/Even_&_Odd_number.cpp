#include<iostream>
using namespace std;
int main()

{
        int num;
        cout<<"Enter any Numbers:"<<endl;
        cin>>num;

        if(num%2==0)
       {
        cout<<"Even Number:"<<endl;
       }
       else
       {
         cout<<"Odd Number:";
       }
    
};