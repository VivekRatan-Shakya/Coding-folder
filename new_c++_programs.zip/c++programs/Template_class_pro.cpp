#include<iostream>
using namespace std;
template <class A>
class show
{
    public:
     show( A y,A x)
  {
      cout<<y<<endl<<x<<endl;
  }
};
int main()
{
     show <int> obj(20,20);
    return 0;
}





// #include<iostream>
// using namespace std;
// template <class A>
// class print
// {
//     public:
//     print( A y,A x)
//    {
//        cout<<y<<endl<<x<<endl;
//    }
// };

// int main()
// {
//    // print <int> obj(50,30);
//     print <float> obj(20.3,52.02);
//     return 0;
// }







