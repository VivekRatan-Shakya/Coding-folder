#include<iostream>
using namespace std;
 int count=0;
  
class A
{
       public:
       int k=count;
   A()
   {
     
      cout<<"Object Created"<<endl<<++count;
   }
 A(A &ref)
 {
    k=ref.k;
    cout<<"Second object Created"<<endl<<k;
 }
};
int main()
{
    A obj;
    A obj2=obj;
    
    return 0;
}