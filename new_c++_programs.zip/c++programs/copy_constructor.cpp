#include<iostream>
using namespace std;
class K
 {     int c;
      public:
   K(int x, int y)
    {
        int z;
        c=z=x*y;
        cout<<"Result is = :"<<z<<endl;
    }
K(K &ref)
    {
          c=ref.c;
          cout<<"Result is = :"<<c<<endl;
    }
};
int main()
{
    K obj(20,30);
    K obj2=obj;
                return 0;
}