<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php

// sum  of student number and percentage 

// $name="Shivam";   
// $class="12th";
// $h=90; 
// $e=56;
// $m=63;
// $c=78; 
// $p=82;

// $total=$h+$e+$m+$c+$p; 
// $per=$total/5; 

// echo " The Name is=$name<br>";
// echo "The Class is=$class<br>";
// echo "The Number is=$total <br>";
// echo "The percentage is=$per <br>";

// true&false
// $a=60;
// $b=60;

// $c=$a==$b;
// echo $c;

///// Equal&!equal
// 

//all mix datatype values

// $a=55.02;
// $b=51;
// $c="false";
// $d="Shivam";
// $e=[5,6,98,5];
// $f=null;


// echo $a,$b,$c,$d,$e,$f;

//echo str_word_count("So you kno how can i help you");


//echo strpos("So you kno how can i help you","S");


// String function

// string print;
// string reverse;
// string replace;
// string length print;
// string size print;
// string index number print;
// string random values print;
// string between number 1 to 10 number print of length;
// string special charchater print;

//$str1="Anonymouse";

 //echo "Print String= $str1<br>";
 //echo "Reverse string is=" .strrev($str1);
 //echo "Replace of String is=".str_replace("word","Hello","Word");
 //echo"the length of string =".strlen($str1);

 
//  $a=10;
//  $b=60;

//  $c=$a;

//  echo $c;
//  echo $b;
//  echo $a;
//  echo $a+$b+$c;

// $a=30;
// $b=30;

// if($a==$b)
// {
//     echo "that is true";
// }
// else if  ($a!=$b)
// {
//      echo "tha is false";
// }




// $a=90;
// $b=90;

// if($a<$b)
// {
//     echo "that true";
// }
// else if($a>$b)
// {
//     echo "tha is false";
// }
// else if($a==$b)
// {
//     echo "That is Equal";
// }



// $a=1170;
// $b=160;
// $c=90;

// if($a>$b && $a>$c)
// {
//     echo " A is greater no.";
// }
// else if($b>$a && $b>$c)
// {
//     echo "B is greater no.";
// }

// else if($c>$a && $c>$b)
// {
//     echo " C is greater no.";
// }

// ++preincrement & postincrement++

 //$a=80;
 //$c=++$a;
 // $c=$a++;
 
 //echo $c;
 //echo $a;

// --preincrement & postdecrement--

//$x=50;
 //$d=$x--;
 //$d=--$x;

//echo $d;
//echo $x;

// ||Or operator error

// $a=1;
// $b=6;
// $c=8;

// if($a>$b || $a>$c)
// {
//     echo " tha is false";
// }
// else if($a!>$b || $a!>$c)

// {

//     echo "false";
// }

//  $name="Vishal Verma";
// // $name2="shivani Sharma";

// // echo "$name,$name2";

// $txt .=$name;
// echo $txt;


// Even number programs

// $num=32;


// if($num%2==0)
// {
//     echo "is a Even no.";
// }
// else
// {
//     echo " odd no.";
// }


// Balance withdrawal

// $balance=50000;
// $withdrawal=33000;

// if($withdrawal<=$balance)
// {
//   $balance =-$withdrawal;
//  echo $withdrawal,"Rupees have been withdrawal successful A/c XXXX5230";
// }
// else{
//     echo "! Enough  Balance on your A/c";
// }

// calculate number and percentage

// $name="Aman";
// $per;
// $total;

// $h=80;
// $e=70;
// $m=93;
// $p=63;
// $c=57;

// $total=$h+$e+$m+$p+$c;
// $per=total/5;
// echo "<h2>Student Details is</h2>";
// echo "<br>Student Name is = ",$name;
// echo "<br>Total Number is = ",$total,"  Pass:";


// echo  "The Percentage is = ",$per;


$per=94;

if($per<=90)
{
echo "A";

}
else if($per<=70)
{
    echo "B";
}
else if($per<=50)
{
    echo "c";

}
else
{
    echo "Fail";
}










?>



</body>
</html>