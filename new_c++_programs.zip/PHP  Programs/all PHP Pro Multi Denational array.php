<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
  <body style="background-color:black;">
 <p style="color:white;"> 
<?php



//  Multi demational  array:

//   $mobile=array( 
//   array("Apple","57000","12"),
//   array("Samsung","17000","14"),
//   array("Vivo","13000","16"),
//   array("Realme","16000","19"),
//   array("Onepluse","19000","30")
//  );
//  {echo "It,s Product list:<br><br>";}
//  for($row=0;$row<5;$row++)
//  {
//  for($col=0;$col<3;$col++)
//   {
//   echo $mobile[$row][$col];
//   echo " | ";}
//   echo "<br>";
//  }




































?>    



</body>
</html>