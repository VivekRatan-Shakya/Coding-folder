<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>

 <body style="background-color:black;">
 <p style="color:white;"> 




<?php

 // find the grade of Students:
//  $name="Sumit";
//  $class="12th";
//  $per="70.01%";

//   echo "$name<br>";
//   echo "$class<br>";
//   echo "$per<br>"; 

// if($per>=90)
// {
//     echo " The Grade is = A+";
// }
// else if($per>=80)
// {
//     echo "The Grade is = B+";
// }
// else if($per>=70)
// {
//     echo "The Grade is = C+";
// }
// else
// {
//     echo "Fail";
// }


// find the vowel and consonants:


// $choice=1;
// echo "Choose the operations:<br>";
//   switch($choice)
// {
//     case 1:
//     echo "1 for vowels find out<br>";
//     break;
//     case 2:
//     echo "2 for consonants find out";
//     break;
//     default:echo"Wrong Choice";
// }

// $x=5;

// switch($choice)
// {
//     case 1:
//         {
//             echo "square of ", $x,"  is:",$x*$x;
//         }
// }


// $choice='M';
// echo "Enter you chiice: <br><br>";
// switch($choice)
// {
//     case 'a':
//         echo "This is vowel";
//         break;
//     case 'e':
//         echo "This is vowel";
//         break;
//         case 'i':
//             echo "This is vowel";
//             break;
//             case 'u':
//                 echo "This is vowel";
//                 break;
//                 case 'o':
//                     echo "This is vowel";
//                     break;


//  case 'A':
//         echo "This is vowel";
//          break;

//          case 'E':
//             echo "This is vowel";
//             break;

//             case 'I':
//                 echo "This is vowel";
//                 break;

//                 case 'O':
//                     echo "This is vowel";
//                     break;

//                     case "U":
//                         echo "This is vowel";
//                         break;

//                         default:
//                         echo "That is consonant";
                        
//                     }

                    

                
        
// looping statement
// for loop:

  // for($i=0; $i<=5;$i++)
    // {
    //   echo $i;
    //   echo "<br>";
    // }

// Even numbers
    // for($i=1;$i<=100;$i++)
    // {
    //  if($i%2==0)

    //  echo $i;
    //  echo "<br>";
    // }
             
    // Odd Numbers

    // for($i=1;$i<=200;$i++)
    //  {
    //   if($i%2!=0)
    //   echo $i;
    //   echo "<br>";

    //  }

 //Print the Tables
//    $num=19; 
//    $k;
//   for($i=1;$i<=10;$i++)
//   {
//     $k=$num*$i;

//     echo " $num X $i =$k ";
//     echo "<br>";
//   }  



// for($i=1;$i<=10;$i++)
// {
//   echo "*";
//   echo "<br>";
// }

// while for
// $i=1;

// while($i<=10)
// {
//   echo "$i";
//   echo "<br>";

//   $i++;
// }
// do while loop for php;
// $i=1;

// do{
//   echo "$i";
//   echo "<br>";
//   $i++;
//   }
// while($i<=10)
// $num=5;
// $k;
// $i=1;

// do
// {
//   $k=$num*$i;
//  echo " $num X $i  $k";
//  echo "<br>";
//  $i++;
// }
// while($i<=10)


// USER DEFINE FUNCTION FOR PHP:

//  echo "It,s is Efficiency this word:<br>";
//  function printline()
//  { for($i=1;$i<=80; $i++)
//  { echo "-";}
//  }
//  printline();
//  echo "<br>HI Shri<br>";
//  printline();


// function 1:
// function aman()
// {
// for($i=1;$i<=3;$i++)
// {echo "*<br>";}
// }
// // funtion 2:
// function shivam()
// {
//   for($i=1;$i<=3;$i++)
//   { echo "+<br>";}
// }
// //  funtion 3:
// function priya()
// {
//   for($i=1;$i<=3;$i++)
//   { echo "love you jaan<br>";}
// }
// function 4:
// function pallvi()
// {
//   for($i=1;$i<=3;$i++)
//   { echo "750012<br>";}
// }

// // all funtion call:

// aman();
// shivam();
// priya();
//  pallvi();
 



// Calculate percentage;

// function percentage($totalnum)
// {
//   $per=$totalnum/5;
//   return($per);
// }

//  echo "Aman totan number is = 430 & percentage is = ";
//  echo percentage(430);

//  echo "<br>Sunil totan number is = 420 & percentage is = ";
//  echo percentage(420);

//  echo " <br>Prashant totan number is = 460 & percentage is = ";
//  echo percentage(460);

//  echo " <br>Priya totan number is = 450 & percentage is =";
//  echo percentage(450); 

//  echo "<br>Raveena totan number is = 490 & percentage is = ";
//  echo percentage(490);

// Arrays function;

// function array()
// {
//  $name=array("Raveena","Shivani","Priti","Pallvi","Suhana");
//  echo $name;
// }

// array();

//   $name =array("Raveena","Shivani","Priti","Pallvi","Suhana");
//   for($i=0;$i<=4; $i++)
//  {
//     echo $name[$i];
//     echo "<br>";
//   }

 // Array index numberd Prints;

//  $name =array("Lavi","Sunena","Kajal","Payal","Palak");
//  $arraylength=count($name);
//  for($i=0;$i<$arraylength;$i++)
//  {
//    echo "Index number [$i] ",$name[$i];
//    echo "<br>";
//  }

// $value=array("Hin"=>"63", "eng"=>"90","phy"=>"85","che"=>"75","math"=>"82");

// echo "Shivam has got &nbsp".$value['phy']."&nbspmarks";


// Multi demational  array:

//  $mobile=array( 
//   array("Apple","57000","12"),
//   array("Samsung","17000","14"),
//   array("Vivo","13000","16"),
//   array("Realme","16000","19"),
//   array("Onepluse","19000","30")
// );
// {echo "It,s Product list:<br><br>";}
// for($row=0;$row<5;$row++)
//  {
//  for($col=0;$col<3;$col++)
//   {
//   echo $mobile[$row][$col];
//   echo " | ";}
//   echo "<br>";
//  }






















?>
</p>

</body>
</html>