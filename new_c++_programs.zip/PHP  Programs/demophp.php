<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    
<?php
  
// Basic Programs
 
// $a=20;
// $b=30;

// $c=$a+$b;

// echo "The Total Number is= $c";

// the Substraction
// $a=50;
// $b=20;

// $c=$a-$b;

// echo "THe Substraction =$c";

// The Multiplication
// $a=2;
// $b=3;

// $c=$a*$b;

// echo "The Multiplication is =$c";


// The division

// $a=227;
// $b=30;

// $c=$a/$b;

// echo "The devide is =$c";








 ?>




</body>
</html>