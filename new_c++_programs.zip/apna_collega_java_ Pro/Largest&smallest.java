public class Largest&smallest{
    
}
