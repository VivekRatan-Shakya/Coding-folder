public class traped_RainWater 
{
 public static int trapedRainWayer(int height[])  
 {
 int leftMax[]=new int [height.lenght];
 leftMax[0]=height[0];
 for(int)
 }

 public static void main(String[]args)
 {

    int height[]={4,2,0,6,3,2,5};
 }

}
