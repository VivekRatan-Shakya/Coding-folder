public class tringle_pattenr 
{
public static void tringle(int n) 
{
    int  counter=1;
    for(int i=1;i<=n;i++)
    {
        for(int j=1;j<=i;j++)
    }
}   
}
